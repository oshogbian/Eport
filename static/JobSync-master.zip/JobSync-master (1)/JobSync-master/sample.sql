INSERT INTO item VALUES (
    1,
    'Software Engineer', 
    'Tech Innovators Inc.',
    'https://techinnovators.com/jobs/software-engineer',
    'full-time',
    'salary',
    85000.0,
    'Requires proficiency in Python and JavaScript.',
    '2024-05-03 09:30:00',
    1
);

INSERT INTO item VALUES (
    2,
    'Marketing Manager',
    'Creative Solutions Ltd.',
    'https://creativesolutions.com/careers/marketing-manager',
    'full-time',
    'salary',
    70000.0,
    'Must have 5 years of experience in digital marketing.',
    '2024-05-03 10:15:00',
    1
);

INSERT INTO item VALUES (
    3,
    'Administrative Assistant',
    'Biz Support Services',
    'https://bizsupport.com/jobs/admin-assistant',
    'part-time',
    'hourly',
    18.0,
    'Requires excellent organizational skills.',
    '2024-04-20 11:00:00',
    2
);

INSERT INTO item VALUES (
    4,
    'Data Analyst',
    'Insightful Analytics Corp.',
    'https://insightfulanalytics.com/careers/data-analyst',
    'full-time',
    'salary',
    75000.0,
    'Looking for candidates proficient in SQL and Python.',
    '2024-04-25 11:45:00',
    3
);

INSERT INTO item VALUES (
    5,
    'Customer Service Representative',
    'Friendly Telecoms',
    'https://friendlytelecoms.com/jobs/customer-service-rep',
    'part-time',
    'hourly',
    16.0,
    'Previous experience in customer service is preferred.',
    '2024-05-01 12:30:00',
    4
);

INSERT INTO item VALUES (
    6,
    'Graphic Designer',
    'Visual Creations Studio',
    'https://visualcreations.com/careers/graphic-designer',
    'full-time',
    'salary',
    60000.0,
    'Requires experience with Adobe Creative Suite.',
    '2024-05-02 13:15:00',
    3
);
