# Python Virtual Environment

This project uses a python virtual environment to manage dependencies. To set
up your virtual environment:

## Windows or Linux

    python -m venv .venv

To activate your virtual environment in your shell:

## Windows (Powershell):

    .venv\Scripts\Activate.ps1

## Windows (Command Prompt):

    .venv\Scripts\activate.bat

## Linux (Bash):

    source .venv/bin/activate

And to install the needed dependencies:

## Windows or Linux

    pip install -r requirements.txt

# SQLite Database

The database for this project is managed using SQLite. The database should be
created automatically by the Flask app at `instance/database.db`.
