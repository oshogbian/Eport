from dotenv import load_dotenv
from flask import Flask
from jobsync.database import init_db
from os import getenv
import mimetypes

# Initialize MIME types for JavaScript module loading
mimetypes.add_type('text/javascript', '.js')
mimetypes.add_type('text/javascript', '.mjs')

# Initialize the app.
app = Flask(__name__)

# Load environment variable configuration from a .env file in the project root.
load_dotenv()

# Set app configuration options.
app.config["GOOGLE_CLIENT_ID"] = getenv("GOOGLE_CLIENT_ID")
app.config["GOOGLE_CLIENT_SECRET"] = getenv("GOOGLE_CLIENT_SECRET")
app.config["GOOGLE_DISCOVERY_URL"] = (
    "https://accounts.google.com/.well-known/openid-configuration"
)
app.secret_key = getenv("FLASK_SECRET_KEY").encode()

# Initialize the database, if it isn't already.
init_db()

# Import our views.
import jobsync.views.home
import jobsync.views.login
import jobsync.views.schedule
import jobsync.views.analytics

if __name__ == "__main__":
    app.run(debug=True, ssl_context=('cert.pem', 'key.pem'))
