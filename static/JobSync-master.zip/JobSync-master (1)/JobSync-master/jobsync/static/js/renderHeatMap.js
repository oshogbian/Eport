export function renderHeatMap(data) {
    const cal = new CalHeatmap();

    cal.paint({
        itemSelector: '#cal-heatmap',
        data: { 
            source: data,
            x: 'date',
            y: 'count',
        },
        domain: {
            type: 'month',
            gutter: 4,
            padding: [0, 0, 0, 0],
            dynamicDimension: true,
            sort: 'asc',
        },
        subDomain: { 
                type: 'ghDay',
                dynamicDimension: true,
        },
        date: { start: new Date('2024-01-01') },
        scale: {
            color: {
                scheme: 'Cool',
                type: 'linear',
                domain: [0, 40],
            },

        },
        tooltip: true,
    });
}
