export function renderPieChart(json) {
    var labels = new Array();
    var data = new Array();

    for (const obj of json) {
        labels.push(obj.name);
        data.push(obj.count);
    }

    var ctx = document.getElementById('pie-chart').getContext('2d');
    var analyticsPieChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [
                {
                    data,
                    backgroundColor: [
                        'rgb(54, 140, 225)',
                        'rgb(115, 246, 90)',
                        'rgb(0, 0, 0)',
                        'rgb(100, 79, 193)',
                    ],
                    hoverOffset: 30,
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false,
                    text: 'Category Analysis'
                }
            }
        },
    });
}
