import { renderPieChart } from "/static/js/renderPieChart.js";
import { renderLineChart } from "/static/js/renderLineChart.js";
import { renderHeatMap } from "/static/js/renderHeatMap.js";

document.addEventListener("DOMContentLoaded", (_event) => {
    fetch("/analytics/piechart-data")
        .then(response => response.json())
        .then(data => renderPieChart(data));

    fetch("/analytics/heatmap-data")
        .then(response => response.json())
        .then(data => renderHeatMap(data));

    fetch("/analytics/linechart-data")
        .then(response => response.json())
        .then(data => renderLineChart(data))
});
