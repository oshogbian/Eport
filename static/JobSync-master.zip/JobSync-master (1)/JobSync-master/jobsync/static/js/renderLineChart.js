export function renderLineChart(data) {
    const DATA_COUNT = data.length;
    const NUMBER_CFG = {count: DATA_COUNT, min: -100, max: 100};

    const chartData = {
        labels: data.map((x) => x.date),
        datasets: [{
            label: 'Total',
            fill: false,
            backgroundColor: 'rgb(0, 0, 0)',
            borderColor: 'rgb(0, 0, 0)',
            data: data.map((x) => x.count)
        }]
    };

    var ctx = document.getElementById('line-chart').getContext('2d');

    var analyticsLineChart = new Chart(ctx, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Month'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Value'
                    }
                }
            }
        }
    });
}
