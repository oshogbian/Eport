
function showItemForm(button) {
    const form = button.parentNode.querySelector(".add-item-form");

    if (form.classList.contains('add-item-form-visible')) {
        button.innerHTML = "<i class=\"fa fa-plus\"></i>&nbsp;&nbsp;ADD A NEW ITEM";
        button.classList.remove("btn-danger");
        button.classList.remove("mb-2");

        form.classList.remove('add-item-form-visible');
        form.classList.add('add-item-form-hidden');
    } else {
        button.innerHTML = "CANCEL";
        button.classList.add("btn-danger");
        button.classList.add("mb-2");

        form.classList.remove('add-item-form-hidden');
        form.classList.add('add-item-form-visible');
    }
}

function sortItems(value) {
    const containers = document.querySelectorAll('.all-items-container');

    for (const container of containers) {
        const items = Array.from(container.querySelectorAll('.item-container'), function (item) {
            let key = "";

            switch (value) {
                case "date-added":
                    key = item.querySelector('.item-timestamp').textContent;
                    break;
                case "title":
                    key = item.querySelector('.item-title').textContent;
                    break;
                case "company":
                    const queryCompany = item.querySelector('.item-company')
                    if (queryCompany !== null) {
                        key = queryCompany.textContent;
                    }
                    break;
                case "comp-amount":
                    const queryCompAmount = item.querySelector('.item-comp-amount')
                    if (queryCompAmount !== null) {
                        key = queryCompAmount.textContent;
                    }
                    break;
            }

            return { item, key };
        });

        const sorted = items.sort((a, b) => a.key > b.key ? 1 : -1);

        container.replaceChildren(...sorted.map((x) => x.item));
    }
}

function searchItems(value) {
    const items = document.querySelectorAll('.item-container');

    console.log(value);

    for (const item of items) {
        let title = "";
        let company = "";
        let notes = "";

        if (item.querySelector('.item-title') !== null) {
            title = item.querySelector('.item-title').textContent;
        }

        if (item.querySelector('.item-company') !== null) {
            company = item.querySelector('.item-company').textContent;
        }

        if (item.querySelector('.item-notes') !== null) {
            notes = item.querySelector('.item-notes').textContent;
        }

        const re = new RegExp(value, "i")
        let match = false;

        match ||= re.test(title);
        match ||= re.test(company);
        match ||= re.test(notes);

        if (match || value.length == 0) {
            item.classList.remove('item-hidden');
        } else {
            item.classList.add('item-hidden');
        }
    }
}
// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function() {
    // Get a reference to the element with the ID "calendarEl"
    const calendarEl = document.getElementById("calendarEl");
  
    // Check if the element was found
    if (calendarEl) {
      // Clear the element's content
      calendarEl.innerHTML = '';
    } else {
      console.error("Element with ID 'calendarEl' not found.");
    }
  });

// Array to store events
let events = [];

// when the window loads
window.onload = () => {
    // get the user events from the document
    var user_events = JSON.parse(document.getElementById("user-events-data").textContent);

    // loop over every event and add it to the events array
    for (var i in user_events)
    {
        var event = user_events[i];
        
        var newEvent = {
            title: event.title,
            description: event.description,
            date: new Date(event.date)
        }

        events.push(newEvent);
    }

    // render the events with all of the events loaded
    renderEvents();
}

// Function to display the event form with the clicked date
function showEventForm(date) {
    const eventForm = document.getElementById('event-modal-form');
    const eventDateInput = document.getElementById('event-date');
    eventDateInput.value = date.toLocaleDateString(); // Set the value of the hidden input to the clicked date
    eventForm.classList.remove('add-item-form-hidden');
    eventForm.classList.add('add-item-form-visible');

    // Assign the date to a global variable
    window.eventDate = date;
}

// Function to hide the event form
function hideEventForm() {
    const eventForm = document.getElementById('event-modal-form');
    eventForm.classList.remove('add-item-form-visible');
    eventForm.classList.add('add-item-form-hidden');
}

// Add an event
function addEvent() {
    const titleInput = document.getElementById('event-title').value;
    const descriptionInput = document.getElementById('event-description').value;

    // Create the event object
    const eventObj = {
        title: titleInput,
        description: descriptionInput,
        date: window.eventDate
    };

    // Add the event object to the events array
    events.push(eventObj);

    // Render the events
    renderEvents();

    // save user events to the database
    fetch("/schedule/save_user_events", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(events)
    })
    .then(response => {
        if (!response.ok)
            console.error("Failed to save user events");
    })
    .catch(err => console.error(err));

    // Clear the form and hide it
    document.getElementById('event-title').value = '';
    document.getElementById('event-description').value = '';
    hideEventForm();
}

// Render events
function renderEvents() {
    const eventsColumn = document.querySelector('.events-list');
    eventsColumn.innerHTML = ''; // Clear the events column

    // Loop through the events array and create event elements
    events.forEach((event, index) => {
        const eventElement = document.createElement('div');
        eventElement.classList.add('event');
        eventElement.innerHTML = `
            <h3>${event.title}</h3>
            <p>${event.description}</p>
            <p>Date: ${event.date.toDateString()}</p>
            <button class="delete-event" data-index="${index}">Delete</button>
        `;

        // Add event listener for delete button
        const deleteButton = eventElement.querySelector('.delete-event');
        deleteButton.addEventListener('click', () => {
            deleteEvent(index);
        });

        eventsColumn.appendChild(eventElement);
    });
}

// Delete an event
function deleteEvent(index) {
    // send the event to be deleted to the server
    fetch("/schedule/delete_user_event", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(events[index])
    })
    .then(response => {
        if (!response.ok)
            console.error("Failed to save user events");
    })
    .catch(err => console.error(err));

    events.splice(index, 1); // Remove the event from the events array
    renderEvents(); // Re-render the events
}

// Function to create the calendar
function createCalendar(year, month) {
    const calendarEl = document.getElementById('calendar');
    calendarEl.innerHTML = ''; // Clear the calendar element

    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const currentMonthName = monthNames[month];

    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const lastDayOfMonth = new Date(year, month + 1, 0).getDay();

    const calendarContainer = document.createElement('div');
    calendarContainer.classList.add('calendar-container');

    // Create and style the calendar header
    const calendarHeader = document.createElement('div');
    calendarHeader.classList.add('calendar-header');

    // Add previous month button
    const prevMonthButton = document.createElement('button');
    prevMonthButton.classList.add('month-nav');
    prevMonthButton.textContent = '<';
    prevMonthButton.addEventListener('click', () => {
        const prevMonth = month === 0 ? 11 : month - 1;
        const prevYear = month === 0 ? year - 1 : year;
        createCalendar(prevYear, prevMonth);
    });

    // Add month name
    const monthNameEl = document.createElement('span');
    monthNameEl.classList.add('month-name');
    monthNameEl.textContent = `${currentMonthName} ${year}`;

    // Add next month button
    const nextMonthButton = document.createElement('button');
    nextMonthButton.classList.add('month-nav');
    nextMonthButton.textContent = '>';
    nextMonthButton.addEventListener('click', () => {
        const nextMonth = month === 11 ? 0 : month + 1;
        const nextYear = month === 11 ? year + 1 : year;
        createCalendar(nextYear, nextMonth);
    });

    // Append the elements to the calendar header
    calendarHeader.appendChild(prevMonthButton);
    calendarHeader.appendChild(monthNameEl);
    calendarHeader.appendChild(nextMonthButton);

    // Append the calendar header to the container
    calendarContainer.appendChild(calendarHeader);

    const calendarGrid = document.createElement('div');
    calendarGrid.classList.add('calendar-grid');
    calendarGrid.classList.add(`month-${month}`); // Add a class for the current month

    let day = 1;
    let previousMonthDays = 0;
    let nextMonthDays = 0;

    // Calculate the number of days from the previous month
    for (let i = firstDayOfMonth - 1; i >= 0; i--) {
        const prevMonthDate = new Date(year, month, 0);
        prevMonthDate.setDate(prevMonthDate.getDate() - i);
        previousMonthDays++;
    }

    for (let i = 0; i < 6; i++) {
        const week = document.createElement('div');
        week.classList.add('week');

        for (let j = 0; j < 7; j++) {
            const dateEl = document.createElement('div');
            dateEl.classList.add('date');

            if (previousMonthDays > 0) {
                const prevMonthDate = new Date(year, month, 0);
                prevMonthDate.setDate(prevMonthDate.getDate() - previousMonthDays + 1);
                dateEl.textContent = prevMonthDate.getDate();
                dateEl.classList.add('prev-month');
                previousMonthDays--;
            } else if (day > daysInMonth) {
                dateEl.textContent = ++nextMonthDays;
                dateEl.classList.add('next-month');
            } else {
                dateEl.textContent = day;
                dateEl.addEventListener('click', () => {
                    // Handle "add event" functionality
                    const eventDate = new Date(year, month, day);
                    showEventForm(eventDate); // Pass the clicked date to the form
                });
                day++;
            }

            week.appendChild(dateEl);
        }

        calendarGrid.appendChild(week);
    }

    // Append the calendar grid to the container
    calendarContainer.appendChild(calendarGrid);

    // Append the calendar container to the calendar element
    calendarEl.appendChild(calendarContainer);
}

// Initialize the calendar
  const currentDate = new Date();
  createCalendar(currentDate.getFullYear(), currentDate.getMonth());