"""
Functions and types related to the database.

JobSync uses SQLite3 as the database backend and SQLAlchemy as the ORM.

Here are some resources you might find useful:
    - https://flask.palletsprojects.com/en/3.0.x/patterns/sqlalchemy/
    - https://docs.sqlalchemy.org/en/20/orm/quickstart.html
"""

from .session import init_db
from .session import Session
from .models import Board
from .models import Item
from .models import User


__all__ = ["init_db", "Session", "Board", "Item", "User"]
