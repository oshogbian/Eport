"""
This module contains models in the SQLite3 database.

See the [SQLAlchemy documentation][1] for mapping syntax.

[1]: https://docs.sqlalchemy.org/en/20/orm/mapping_styles.html#orm-declarative-mapping
"""

from flask_login import UserMixin
from sqlalchemy import ForeignKey, DateTime
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from typing import List
from typing import Optional
import bcrypt
from datetime import datetime


class Model(DeclarativeBase):
    """The base model class. All models should inherit this class."""

    pass


class Board(Model):
    """A board that contains job items."""

    __tablename__ = "board"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("user.id"))

    title: Mapped[str]

    next_board: Mapped[Optional[int]] = mapped_column(ForeignKey("board.id"))
    prev_board: Mapped[Optional[int]] = mapped_column(ForeignKey("board.id"))

    items: Mapped[List["Item"]] = relationship(back_populates="board")

    def __init__(self, title, user_id, next_board=None, prev_board=None):
        self.title = title
        self.user_id = user_id

        if next_board is not None:
            self.next_board = next_board

        if prev_board is not None:
            self.prev_board = prev_board


class Item(Model):
    """An item which contains information about a specific job posting."""

    __tablename__ = "item"

    id: Mapped[int] = mapped_column(primary_key=True)

    title: Mapped[str]
    company: Mapped[Optional[str]]
    url: Mapped[Optional[str]]
    empType: Mapped[Optional[str]]
    compType: Mapped[Optional[str]]
    compAmount: Mapped[Optional[float]]
    notes: Mapped[Optional[str]]

    timestamp: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    board_id: Mapped[int] = mapped_column(ForeignKey("board.id"))

    board: Mapped["Board"] = relationship(back_populates="items")

    def __init__(self, title, board_id, company = None, url = None, empType =
                 None, compType = None, compAmount = None, notes = None):

        self.title = title
        self.company = company
        self.url = url
        self.empType = empType
        self.compType = compType
        self.compAmount = compAmount
        self.board_id = board_id
        self.notes = notes


class User(UserMixin, Model):
    """A user of the application."""

    __tablename__ = "user"

    id: Mapped[str] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column()
    email: Mapped[str] = mapped_column(unique=True)
    profile_pic: Mapped[Optional[str]]
    pwhash: Mapped[Optional[str]]

    def __init__(self, id, name, email, profile_pic=None, password=None):
        self.id = id
        self.name = name
        self.email = email

        if profile_pic is not None:
            self.profile_pic = profile_pic

        if password is not None:
            bytes = password.encode("utf-8")
            salt = bcrypt.gensalt()
            self.pwhash = bcrypt.hashpw(bytes, salt).decode("utf-8")


class UserEvent(Model):
    """A user's scheduled event"""

    __tablename__ = "user_event"

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[str] = mapped_column()
    data: Mapped[str] = mapped_column()

    def __init__(self, user_id, data):
        self.user_id = user_id
        self.data = data