"""
Functionality relating to initializing and connecting to the SQLite3 database.
"""

from jobsync.database.models import Board
from jobsync.database.models import Model
from jobsync.database.models import User
from sqlalchemy import create_engine
from sqlalchemy.orm import Session as AlchemySession
from sqlalchemy.exc import IntegrityError
from os import getenv

# This is the database file SQLite3 uses to store the database in. This is a
# relative path.
SQLITE_DATABASE_URL = "sqlite:///database.db"

# By using this file, we can create a launcher for connections to the database.
engine = create_engine(SQLITE_DATABASE_URL)


def init_db():
    """Create all of the required tables in the SQLite3 database."""
    import jobsync.database.models

    Model.metadata.create_all(bind=engine)

    if getenv("JOBSYNC_DEVEL") is not None:
        # If we're not in production, add a test user for development (if it
        # doesn't exist already).
        try:
            session = Session()

            user = User(1, "Test", "test@example.com", password="password")

            session.add_user(user)
            session.commit()
        except IntegrityError:
            pass


class Session(AlchemySession):
    """A scoped connection to the database, which can run queries."""

    def __init__(self):
        super().__init__(engine)

    def add_user(self, user):
        """Add a user and associated boards to the database."""
        self.add(user)

        self.add(Board("Potential", user_id=user.id, next_board=2))
        self.add(Board("Applied", user_id=user.id, prev_board=1, next_board=3))
        self.add(Board("Responded", user_id=user.id, prev_board=2, next_board=4))
        self.add(Board("Interviewed", user_id=user.id, prev_board=3))

        self.commit()
