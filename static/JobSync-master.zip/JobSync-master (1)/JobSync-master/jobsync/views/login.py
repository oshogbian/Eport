"""
Views related to user login, logout, and authentication.
"""

from flask import redirect
from flask import render_template
from flask import request
from flask import url_for
from flask_login import LoginManager
from flask_login import login_required
from flask_login import login_user
from flask_login import logout_user
from flask_login import current_user
from jobsync import app
from jobsync.database import Session
from jobsync.database.models import User
from oauthlib import oauth2
import json
import requests
from sqlalchemy import select
import bcrypt
from random import randint
import sys

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

client = oauth2.WebApplicationClient(app.config["GOOGLE_CLIENT_ID"])


@app.route("/login")
def login():
    return render_template("login.html.j2", current_user=current_user)


@app.route("/login", methods=["POST"])
def login_post():
    session = Session()

    email = request.values.get("email")
    password = request.values.get("password")

    print(email)
    print(request.values)
    print(session.scalars(select(User)).first().email)

    user = session.scalars(select(User).where(User.email == email).limit(1)).first()

    if user is None:
        return redirect(url_for("login", err="User does not exist."))

    given_bytes = password.encode("utf-8")
    hash_bytes = user.pwhash.encode("utf-8")

    if not bcrypt.checkpw(given_bytes, hash_bytes):
        return redirect(url_for("login", err="Password is incorrect."))

    login_user(user)

    return redirect(url_for("home"))


@app.route("/register")
def register():
    return render_template("register.html.j2")


@app.route("/register", methods=["POST"])
def register_post():
    session = Session()

    email = request.values.get("email")
    password = request.values.get("password")

    print(email)
    print(request.values)

    duplicate_user = session.scalars(select(User).where(User.email == email).limit(1)).first()

    if duplicate_user is not None:
        return redirect(url_for("register", err="User already exists."))

    user = User(randint(1, sys.maxsize), name=email, email=email, password=password)

    session.add_user(user)

    return redirect(url_for("login"))


@app.route("/login/google-webauthn")
def login_google_webauthn():
    provider_cfg = requests.get(app.config["GOOGLE_DISCOVERY_URL"]).json()

    print(request.base_url)

    request_uri = client.prepare_request_uri(
        provider_cfg["authorization_endpoint"],
        redirect_uri= request.base_url + "/callback",
        scope=["openid", "email", "profile"],
    )

    return redirect(request_uri)


@app.route("/login/google-webauthn/callback")
def login_callback():
    session = Session()

    code = request.args.get("code")

    provider_cfg = requests.get(app.config["GOOGLE_DISCOVERY_URL"]).json()
    token_endpoint = provider_cfg["token_endpoint"]

    token_url, headers, body = client.prepare_token_request(
        token_endpoint,
        authorization_response=request.url,
        redirect_url=request.base_url,
        code=code,
    )

    client_id = app.config["GOOGLE_CLIENT_ID"]
    client_secret = app.config["GOOGLE_CLIENT_SECRET"]

    token_response = requests.post(
        token_url,
        headers=headers,
        data=body,
        auth=(client_id, client_secret),
    )

    client.parse_request_body_response(json.dumps(token_response.json()))

    userinfo_endpoint = provider_cfg["userinfo_endpoint"]
    uri, headers, body = client.add_token(userinfo_endpoint)
    userinfo_response = requests.get(uri, headers=headers, data=body)

    if not userinfo_response.json().get("email_verified"):
        return "User email not available or not verified by Google.", 400

    unique_id = userinfo_response.json()["sub"]
    email = userinfo_response.json()["email"]
    picture = userinfo_response.json()["picture"]
    given_name = userinfo_response.json()["given_name"]

    user = session.execute(select(User).where(User.id == unique_id)).first()

    if user is None:
        user = User(unique_id, given_name, email, picture)
        session.add_user(user)

    login_user(user)

    return redirect(url_for("home"))


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))


@login_manager.user_loader
def load_user(user_id):
    session = Session()
    return session.execute(select(User).where(User.id == user_id)).scalar_one()
