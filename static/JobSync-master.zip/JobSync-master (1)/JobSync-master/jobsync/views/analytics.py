"""
Views related to the history/analytics page.
"""

from jobsync import app
from jobsync.database import Session
from jobsync.database.models import Item, Board
from flask import render_template
from sqlalchemy import select, func


@app.route("/analytics")
def analytics():
    return render_template("analytics.html.j2")


@app.route("/analytics/heatmap-data")
def heatmap_data():
    session = Session()

    data = session.execute(
        select(func.date(Item.timestamp), func.count())
            .select_from(Item)
            .group_by(func.date(Item.timestamp))
    ).all()

    return list(map(lambda x: { 'date': x[0], 'count': x[1] }, data))


@app.route("/analytics/piechart-data")
def piechart_data():
    session = Session()

    data = session.execute(
        select(Board.title, func.count())
            .select_from(Item)
            .join(Board)
            .group_by(Item.board_id)
    ).all()

    return list(map(lambda x : { 'name': x[0], 'count': x[1] }, data))

@app.route("/analytics/linechart-data")
def linechart_data():
    session = Session()

    query = session.execute(
        select(func.date(Item.timestamp), func.count())
            .select_from(Item)
            .group_by(func.date(Item.timestamp))
    ).all()

    count = 0
    data = []

    for row in query:
        count += row[1]
        data.append({ 'date': row[0], 'count': count })

    return data
