"""
Views related to the main screen (job board screen).
"""

from jobsync import app
from flask import redirect
from flask import request
from flask import url_for
from flask import render_template
from flask_login import login_required
from flask_login import current_user
from jobsync.database import Session
from jobsync.database.models import Board, Item
from sqlalchemy import select


@app.route("/")
@login_required
def home():
    session = Session()

    print(current_user.get_id())

    boards = (
        session.execute(select(Board).where(Board.user_id == current_user.get_id()))
        .scalars()
        .all()
    )

    return render_template("home.html.j2", current_user=current_user, boards=boards, bg_dark=True)


@app.route("/add-item", methods=["POST"])
@login_required
def add_item():
    session = Session()

    title = request.values.get("job-title")
    company = request.values.get("job-company")
    posting = request.values.get("job-posting")
    empType = request.values.get("job-emp-type")
    compType = request.values.get("job-comp-type")
    compAmount = request.values.get("job-comp-amount")
    notes = request.values.get("job-notes")

    if not company:
        company = None

    if not posting:
        posting = None

    if empType == "none":
        empType = None

    if compType == "none":
        compType = None

    if not compAmount:
        compAmount = None

    board_title = request.values.get("job-board")

    board_id = (
        session.execute(
            select(Board)
            .where(Board.title == board_title)
            .where(Board.user_id == current_user.get_id())
        )
        .scalar_one()
        .id
    )

    item = Item(
        title,
        board_id,
        company,
        posting,
        empType,
        compType,
        compAmount,
        notes,
    )

    session.add(item)
    session.commit()

    return redirect(url_for("home"))


@app.route("/move-item", methods=["POST"])
@login_required
def move_item():
    session = Session()

    item_id = request.values.get("item")
    board_id = request.values.get("move-to")

    item = session.execute(select(Item).where(Item.id == item_id)).scalar_one()

    board = session.execute(select(Board).where(Board.id == board_id)).scalar_one()

    item.board = board

    session.commit()

    return redirect(url_for("home"))
