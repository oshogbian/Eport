"""
Views related to the schedule/calendar page.
"""

from jobsync import app
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
from flask_login import current_user
from jobsync import app
from jobsync.database import Session
from sqlalchemy import select
from jobsync.database.models import UserEvent
import json

@app.route("/schedule")
def schedule():
    session = Session()

    user_events_sequence = session.scalars(select(UserEvent).where(UserEvent.user_id == current_user.get_id())).all()
    user_events = [json.loads(item.data) for item in user_events_sequence]

    return render_template("schedule.html.j2", user_events=user_events)

@app.route("/schedule/save_user_events", methods=["POST"])
def save_user_events():
    session = Session()

    data = request.json

    for item in data:
        if session.execute(select(UserEvent).where(UserEvent.user_id == current_user.get_id()).where(UserEvent.data == json.dumps(item))).first() != None:
            continue

        event = UserEvent(current_user.get_id(), json.dumps(item))
        session.add(event)

    session.commit()

    return redirect(url_for("schedule"))

@app.route("/schedule/delete_user_event", methods=["POST"])
def delete_user_event():
    session = Session()

    data = request.json

    event = session.query(UserEvent).filter_by(user_id=current_user.get_id(), data=json.dumps(data)).first()
    session.delete(event)

    session.commit()

    return redirect(url_for("schedule"))