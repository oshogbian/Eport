# JobSync

JobSync is an app that helps you keep track of your applications to jobs and
internships.

This is the term project for ITSC-3155, taught by Dr. Mejias at UNCC.

## Licenses

This project includes FontAwesome v4, which is fully open source. See
https://fontawesome.com/v4/license/ for more details.
